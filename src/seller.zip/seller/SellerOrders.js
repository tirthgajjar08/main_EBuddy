import React from 'react'

function SellerOrders() {
  return (
    <div>
      <p>order page</p>
    </div>
  )
}

export default SellerOrders
