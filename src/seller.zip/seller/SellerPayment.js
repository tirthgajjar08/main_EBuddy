import React from 'react';
import { Outlet } from 'react-router'
import { Link } from 'react-router-dom'

function SellerPayment() {
  return (
  <>
      <main id="main"   className="main">

<div className="pagetitle mb-4">
  <h1>Payment List</h1>
  
</div>

<section className="section">
  <div className="row">
    <div className="col-lg-12">

      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Payment</h5>
         
         

          <div className="search-bar justify-content-end">
          <form
            className="search-form d-flex align-items-center"
            method="POST"
            action="#"
          >
            <input
              type="text"
              name="query"
              placeholder="Search Product"
              title="Enter search keyword"
              className='p-1 w-55'
            />
            
            
          </form>
        </div>
          <table className="prolist_style table datatable mt-4">
            <thead>
              <tr>
                <th scope="col">No</th>
                <th scope="col">Payment Id</th>
                <th scope="col">Order Id</th>
                <th scope="col">Payment Mode</th>
                <th scope="col">Amount</th>
                <th scope="col">Date & Time</th>


                <th scope="col">Status</th>
              
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                
                <td> 
                    1245</td>
                <td>order2559</td>
                <td>UPI</td>
                <td>70000</td>

                <td><p>12/05/2023</p>
                    <p>10:16 PM</p>
                </td>


                <td className="m-2 p-2 badge bg-success ">Complete</td>

              
              </tr>
            
            
            </tbody>
          </table>
       
        </div>
      </div>

    </div>
  </div>
</section>

</main>
    <Outlet/>
    </>
  )
}

export default SellerPayment
